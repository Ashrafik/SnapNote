
import React from 'react';
import ReactDOM from 'react-dom';

import './index.css';
import SnapNoteApp from './App';

ReactDOM.render(<SnapNoteApp />, document.getElementById('root'));